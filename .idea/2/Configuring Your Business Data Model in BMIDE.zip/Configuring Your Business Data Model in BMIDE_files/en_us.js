window.l10n = {
    "back_to_collection": "Back to collection",
    "privacy_footer": "Privacy Policy",
    "terms_footer": "Terms of use",
    "siemens_inc": "Siemens Industry Software, Inc.",
    "lms_start_where_last":"Do you want to start where you left off last time?",
    "user_preferences": "User Preferences",
    "restore_defaults": "Restore defaults",
    "save": "Save",
    "settings": "Settings",
    "searchPlaceholder": "Enter your search word here...",
    "searchResults": "Found {0} results for {1}",
    "copy_button": "Copy"
};
